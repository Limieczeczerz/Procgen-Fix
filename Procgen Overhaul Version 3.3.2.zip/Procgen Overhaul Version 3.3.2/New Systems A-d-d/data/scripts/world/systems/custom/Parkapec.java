package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Entities;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.StarSystemType;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

//import com.fs.starfarer.api.impl.campaign.ids.MemFlags;

public class Parkapec {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Parkapec");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background5.jpg");

		//if (Global.getSettings().getBoolean("factionsClaimUnpopulatedCoreSystems")) {
		//	system.getMemoryWithoutUpdate().set(MemFlags.CLAIMING_FACTION, Factions.LUDDIC_CHURCH);
		//}

		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("parkapec", // unique id for this star
				"star_blue_giant",  // id in planets.json
				1300f,          // radius (in pixels at default zoom)
				1000, // corona radius, from star edge
				15f, // solar wind burn level
				3f, // flare probability
				5f); // cr loss mult

		system.setLightColor(new Color(225, 226, 242)); // light color in entire system, affects all entities

		PlanetAPI corvusXa = system.addPlanet("namaru", star, "Boyd", "lava", 0, 180, 4000, 320);
		corvusXa.getSpec().setRotation(2f);
		corvusXa.applySpecChanges();
		PlanetAPI salmu = system.addPlanet("salmu", corvusXa, "Edward", "rocky_metallic", 4, 50, 420, 35);
		salmu.getSpec().setRotation(8f);
		salmu.applySpecChanges();

		SectorEntityToken field0 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						10, // min asteroid count
						20, // max asteroid count
						10f, // min asteroid radius
						13f, // max asteroid radius
						null)); // null for default name
		field0.setCircularOrbit(star, 0+75, 4000, 320);

		SectorEntityToken teamfortress = system.addCustomEntity("teamfortress", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"nav_buoy_makeshift", // type of object, defined in custom_entities.json
				"independent"); // faction
		teamfortress.setCircularOrbitPointingDown(star, 0+75, 4000, 320);

		SectorEntityToken field1 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						10, // min asteroid count
						20, // max asteroid count
						10f, // min asteroid radius
						13f, // max asteroid radius
						null)); // null for default name
		field1.setCircularOrbit(star, 0-75, 4000, 320);

		JumpPointAPI jumpPoint_inner = Global.getFactory().createJumpPoint("jumpPoint_inner", "Inner System Jump-point");
		jumpPoint_inner.setCircularOrbit(star, 0-75, 4000, 320);
		jumpPoint_inner.setRelatedPlanet(corvusXa);
		jumpPoint_inner.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumpPoint_inner);

		PlanetAPI new_bebop = system.addPlanet("new_bebop", star, "New Bebop", "toxic", 24, 130, 5400, 410);
		new_bebop.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		new_bebop.getSpec().setGlowColor(new Color(250, 150, 0, 255));
		new_bebop.getSpec().setPlanetColor(new Color(165, 220, 175, 255));
		new_bebop.getSpec().setUseReverseLightForGlow(true);
		new_bebop.applySpecChanges();
		new_bebop.setCustomDescriptionId("planet_new_bebop");

		SectorEntityToken grozel_station = system.addCustomEntity("grozel_station", "Farlow Tropobserver", "station_hightech2", "luddic_church");
		grozel_station.setCircularOrbitPointingDown(system.getEntityById("new_bebop"), 0, 280, 20);
		grozel_station.setInteractionImage("illustrations", "orbital");

		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 6200, 420f);
		system.addRingBand(star, "misc", "rings_dust0", 512f, 2, Color.white, 256f, 6300, 420f);
		system.addRingBand(star, "misc", "rings_dust0", 512f, 1, Color.white, 256f, 6400, 420f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 6600, 420f);
		system.addRingBand(star, "misc", "rings_dust0", 512f, 0, Color.white, 256f, 6600, 420f);
		system.addTerrain(Terrain.RING, new RingParams(600, 6400, null, null));

		PlanetAPI corvusXb = system.addPlanet("anunnaki", star, "Sovereign", "desert", -50, 160, 7600, 600);
		SectorEntityToken anunnaki_field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(160, // terrain effect band width
						250, // terrain effect middle radius
						corvusXb, // entity that it's around
						170, // visual band start
						330, // visual band end
						new Color(50, 20, 100, 40), // base color
						1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(140, 100, 235),
						new Color(180, 110, 210),
						new Color(150, 140, 190),
						new Color(140, 190, 210),
						new Color(90, 200, 170),
						new Color(65, 230, 160),
						new Color(20, 220, 70)
				));
		anunnaki_field.setCircularOrbit(corvusXb, 0, 0, 10);
		
		SectorEntityToken oro = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						600f, // min radius
						800f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						8f, // min asteroid radius
						12f, // max asteroid radius
						"Aramarra")); // null for default name
		oro.setCircularOrbit(star, 180+60, 10400, 1000);

		SectorEntityToken overwatch = system.addCustomEntity("overwatch", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"comm_relay_makeshift", // type of object, defined in custom_entities.json
				"independent"); // faction
		overwatch.setCircularOrbitPointingDown(star, 180+60, 10400, 1000);

		SectorEntityToken ara = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						600f, // min radius
						800f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						8f, // min asteroid radius
						12f, // max asteroid radius
						"Oromorro")); // null for default name
		ara.setCircularOrbit(star, 180-60, 10400, 1000);

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("ara_jump", "Oro Jump-point");
		jumpPoint.setCircularOrbit(star, 180-60, 10400, 1000);
		jumpPoint.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumpPoint);

		PlanetAPI naibiria = system.addPlanet("naibiria", star, "Naibiria", "gas_giant", 180, 410, 10400, 1000);
		//naibiria.setCustomDescriptionId("planet_naibiria");
		naibiria.getSpec().setTexture( Global.getSettings().getSpriteName("planets", "volturn") );
		naibiria.getSpec().setPlanetColor(new Color(15, 110, 225,255));
		naibiria.getSpec().setCloudColor(new Color(15, 110, 225,255));
		naibiria.getSpec().setIconColor(new Color(15, 175, 225,255));
		naibiria.applySpecChanges();
		PlanetAPI marko = system.addPlanet("marko", naibiria, "Marko", "water", 45, 100, 800, 80);
		marko.setCustomDescriptionId("planet_marko");
		marko.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		marko.getSpec().setGlowColor(new Color(255,241,227,255));
		marko.getSpec().setUseReverseLightForGlow(true);
		marko.applySpecChanges();
		SectorEntityToken field = system.addTerrain(Terrain.MAGNETIC_FIELD,
				new MagneticFieldParams(200f, // terrain effect band width
						200, // terrain effect middle radius
						marko, // entity that it's around
						110f, // visual band start
						310f, // visual band end
						new Color(189, 79, 57, 20), // base color
						2f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(125, 52, 37, 20),
						new Color(196, 82, 59, 40),
						new Color(255, 106, 77, 80),
						new Color(255, 140, 117, 90),
						new Color(184, 84, 72, 105),
						new Color(186, 50, 124),
						new Color(156, 43, 120)
				));
		field.setCircularOrbit(marko, 0, 0, 30);
		PlanetAPI bromium = system.addPlanet("bromium", naibiria, "Bromium", "barren_venuslike", 180, 110, 1100, 85);
		bromium.setCustomDescriptionId("planet_bromium");
		Misc.initConditionMarket(bromium);
			bromium.getMarket().addCondition(Conditions.DECIVILIZED_SUBPOP);
			bromium.getMarket().addCondition(Conditions.RUINS_SCATTERED);
			bromium.getMarket().addCondition(Conditions.ORE_MODERATE);
			bromium.getMarket().addCondition(Conditions.NO_ATMOSPHERE);
		PlanetAPI cranium = system.addPlanet("cranium", naibiria, "Cranium", "lava_minor", 210, 140, 1550, 80);
			cranium.getSpec().setGlowColor(new Color(115,110,245,255));
			cranium.getSpec().setAtmosphereColor(new Color(115,110,245,100));
			cranium.getSpec().setPlanetColor(new Color(115,110,245,255));
			cranium.getSpec().setUseReverseLightForGlow(true);
			cranium.applySpecChanges();

		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 14000, 1320f);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 14100, 1430f);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 14250, 1490f);

		system.addTerrain(Terrain.RING, new RingParams(600, 14100, null, null));

		system.addRingBand(star, "misc", "rings_ice0", 256f, 3, Color.white, 256f, 15300, 1310f);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 15400, 1420f);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 15500, 1540f);

		system.addTerrain(Terrain.RING, new RingParams(600, 15400, null, null));

		PlanetAPI kathryn = system.addPlanet("kathryn", star, "Kathryn", "toxic_cold", 200+40, 220, 17200, 1500);
		system.addRingBand(kathryn, "misc", "rings_special0", 512f, 0, new Color(225,255,215,255), 512f, 800, 100f, Terrain.RING, null);
		kathryn.setCustomDescriptionId("planet_kathryn");
		Misc.initConditionMarket(kathryn);
		kathryn.getMarket().addCondition(Conditions.ORE_MODERATE);
		kathryn.getMarket().addCondition(Conditions.ORGANICS_COMMON);
		kathryn.getMarket().addCondition(Conditions.FARMLAND_POOR);
		kathryn.getMarket().addCondition(Conditions.POOR_LIGHT);
		kathryn.getMarket().addCondition(Conditions.EXTREME_WEATHER);
		kathryn.getMarket().addCondition(Conditions.DENSE_ATMOSPHERE);
		kathryn.getMarket().addCondition(Conditions.VERY_COLD);
		kathryn.setFaction(Factions.HEGEMONY);

		PlanetAPI lamar = system.addPlanet("lamar", star, "Lamar", "ice_giant", 10, 260, 18500, 2000);
		//lamar.setCustomDescriptionId("planet_Lamar")

		StarSystemGenerator.addSystemwideNebula(system, StarAge.YOUNG);

		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}










