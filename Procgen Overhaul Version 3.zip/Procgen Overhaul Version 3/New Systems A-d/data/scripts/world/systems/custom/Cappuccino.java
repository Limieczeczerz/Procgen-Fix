package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;

import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Cappuccino {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Khyber");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background4.jpg");

		//SectorEntityToken hybrasil_nebula = Misc.addNebulaFromPNG("data/campaign/terrain/hybrasil_nebula.png",
		//		0, 0, // center of nebula
		//		system, // location to add to
		//		"terrain", "nebula", // "nebula_blue", // texture to use, uses xxx_map for map
		//		4, 4, StarAge.AVERAGE); // number of cells in texture
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("cappuccino", // unique id for star
				StarTypes.BROWN_DWARF, // id in planets.json
				425f,		// radius (in pixels at default zoom)
				300, // extent of corona outside star
				1f, // solar wind burn level
				0f, // flare probability
				1f); // CR loss multiplier, good values are in the range of 1-5

		system.setLightColor(new Color(162, 29, 155)); // light color in entire system, affects all entities

		PlanetAPI gumbat = system.addPlanet("gumbat", star, "Gumbat", "toxic", -120, 130, 1100, 80);
		gumbat.setCustomDescriptionId("planet_gumbat");
		gumbat.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		gumbat.getSpec().setGlowColor(new Color(181,29,35,155));
		gumbat.getSpec().setPitch(20f);
		gumbat.getSpec().setUseReverseLightForGlow(true);
		gumbat.applySpecChanges();
		SectorEntityToken gumball_station = system.addCustomEntity("gumball_station", "Robyn Tropobserver", "station_side04", "tritachyon");
		gumball_station.setCircularOrbitPointingDown(system.getEntityById("Gumbat"), 0, 250, 15);
		gumball_station.setCustomDescriptionId("gumball_station");

		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 1600, 200f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 1700, 200f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_special0", 256f, 1, Color.white, 256f, 1800, 200f, Terrain.RING, null);

		system.addRingBand(star, "misc", "rings_dust0", 512f, 0, Color.white, 256f, 1850, 155f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 512f, 0, Color.white, 256f, 1850, 210f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 512f, 0, Color.white, 256f, 1850, 240f, Terrain.RING, null);

		//JumpPointAPI JumpPoint = Global.getFactory().createJumpPoint("gumbat_jump", "Inner System Jump-point");
		//JumpPoint.setCircularOrbit( system.getEntityById("cappuccino"), -120-60, 2250, 170);
		//system.addEntity(JumpPoint);
		//JumpPoint.setRelatedPlanet(gumbat);
		//JumpPoint.setStandardWormholeToHyperspaceVisual();

		//system is too crowded, removing these. Brown giant shouldn't have that much shit going on
		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 2600, 210f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 2700, 170f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 2700, 185f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 2800, 155f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 2900, 210f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 3020, 275f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 3120, 240f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 3250, 400f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 512f, 0, Color.white, 256f, 3350, 355f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 512f, 0, Color.white, 256f, 3370, 345f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 512f, 1, Color.white, 256f, 3400, 350f, Terrain.RING, null);
		//https://youtu.be/Jn06G6hu9uU

		PlanetAPI mambo = system.addPlanet("mambo", star, "Kohat", "lava", -120, 200, 4550, 310);

		system.addRingBand(mambo, "misc", "rings_dust0", 256f, 1, Color.white, 512f, 600, 45f, null, null);
		system.addAsteroidBelt(mambo, 10, 600, 200, 60, 100, Terrain.ASTEROID_BELT, null);

		SectorEntityToken asteroid_field1 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						600f, // max radius
						10, // min asteroid count
						50, // max asteroid count
						5f, // min asteroid radius
						10f, // max asteroid radius
						null)); // null for default name
		asteroid_field1.setCircularOrbit(star, -120-60, 4550, 310);

		SectorEntityToken asteroid_field2 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						600f, // max radius
						10, // min asteroid count
						50, // max asteroid count
						5f, // min asteroid radius
						10f, // max asteroid radius
						null)); // null for default name
		asteroid_field2.setCircularOrbit(star, -120+60, 4550, 310);
		
		JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("jumpPoint2", "Inner System Jump-point");
		jumpPoint2.setCircularOrbit( star, -120+60, 4550, 310);
		jumpPoint2.setRelatedPlanet(mambo);
		system.addEntity(jumpPoint2);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
				2, 2, // min/max entities to add
				6000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				true); // whether to allow habitable worlds

		SectorEntityToken gumbat_buoy = system.addCustomEntity("gumbat_buoy", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"nav_buoy", // type of object, defined in custom_entities.json
				"tritachyon"); // faction
		gumbat_buoy.setCircularOrbitPointingDown(star, 80-45, 11000, 900);

		PlanetAPI grabuz = system.addPlanet("grabuz", star, "Lachi", "ice_giant", -45, 320, 11000, 900);
		//grabuz.setCustomDescriptionId("planet_grabuz");
		//PlanetAPI sos = system.addPlanet("sos", grabuz, "Dara Adam Khel", "cryovolcanic", 40, 40, 500, 36);
		system.addRingBand(grabuz, "misc", "rings_special0", 256f, 1, new Color(200,200,200,255), 256f, 800, 500f, Terrain.RING, null);
		system.addRingBand(grabuz, "misc", "rings_special0", 256f, 1, new Color(200,200,200,255), 256f, 900, 550f, Terrain.RING, null);

		//PlanetAPI som = system.addPlanet("som", grabuz, "Song of Mind", "barren2", 40, 80, 1200, 110);

		SectorEntityToken nebula = system.addTerrain(Terrain.NEBULA, new BaseTiledTerrain.TileParams(
						"       xx " +
						"  xx xxxxx" +
						"   xxxxxx " +
						"xxxxxxxxxx" +
						"xxxxx xx  " +
						"xxxx    x ",
				10, 6, // size of the nebula grid, should match above string
				"terrain", "nebula_blue", 4, 4, null));
		nebula.setCircularOrbit(star, -80-45, 11000, 900);

		SectorEntityToken gumbat_relay = system.addCustomEntity("gumbat_relay", // unique id
				"Free TV Corporate Satellite", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"tritachyon"); // faction
		gumbat_relay.setCircularOrbitPointingDown(grabuz, -225, 2000, 900);
		
		system.addRingBand(star, "misc", "rings_dust0", 512f, 0, Color.white, 256f, 13000, 1206f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 512f, 2, Color.white, 256f, 13050, 906f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 512f, 1, Color.white, 256f, 13050, 860f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 512f, 1, Color.white, 256f, 13100, 960f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_special0", 512f, 1, Color.white, 256f, 13100, 1260f, Terrain.RING, null);

		PlanetAPI carpet = system.addPlanet("carpet", star, "Dara Adam Khel", "barren3", -120, 95, 13550, 1200);

		system.autogenerateHyperspaceJumpPoints(true, true);

		//StarSystemGenerator.addSystemwideNebula(system, StarAge.OLD);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
		
	
}
