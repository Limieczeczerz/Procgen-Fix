package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldSource;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.util.Misc;
//import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Syzygy {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Syzygy");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background_galatia.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("syzygy", // unique id for star
				"star_browndwarf", // id in planets.json
				420f,		// radius (in pixels at default zoom)
				300, // extent of corona outside star
				1f, // solar wind burn level
				0f, // flare probability
				1f); // CR loss multiplier, good values are in the range of 1-5

		//system.setLightColor(new Color(176, 29, 155)); // light color in entire system, affects all entities
		system.setLightColor(new Color(180, 205, 150)); // light color in entire system, affects all entities

		PlanetAPI darth_idiot = system.addPlanet("darth_idiot", star, "Darth Idiot", "rocky_metallic", -20, 130, 1500, 100);

		//JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Gaygan Jump-Point");
		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Syzygy Jump-Point");
		jumpPoint.setCircularOrbit(darth_idiot, 360, 700, 100);
		jumpPoint.setRelatedPlanet(darth_idiot);
		system.addEntity(jumpPoint);

		PlanetAPI abo = system.addPlanet("abo", star, "Abo", "barren2", -300, 100, 2800, 200);
		//used to check temperature

		system.addRingBand(star, "misc", "rings_dust0", 512f, 0, new Color(155, 155, 255), 256f, 3500, 220f, Terrain.RING, null);


		PlanetAPI gagner = system.addPlanet("gagner", star, "Gagner", "rocky_ice", -100, 135, 4500, 280);
		gagner.setCustomDescriptionId("planet_gagner");
		gagner.setInteractionImage("illustrations", "industrial_megafacility");
		gagner.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
		gagner.getSpec().setGlowColor(new Color(197,34,245,255));
		gagner.getSpec().setUseReverseLightForGlow(true);
		gagner.getSpec().setPitch(-20f);
		gagner.getSpec().setTilt(60f);
		gagner.applySpecChanges();

		PlanetAPI amnesia = system.addPlanet("amnesia", star, "Amnesia", "ice_giant", 100, 360, 6900, 500);
		PlanetAPI memory = system.addPlanet("memory", amnesia, "Memory", "frozen", -100, 60, 700, 100);
		system.addRingBand(amnesia, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 940, 100f);
		system.addRingBand(amnesia, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 1000, 100f);
		system.addRingBand(amnesia, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 1080, 100f);
		system.addRingBand(amnesia, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 1110, 100f);
		system.addRingBand(amnesia, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 1160, 100f);
		system.addRingBand(amnesia, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 1240, 80f);
		system.addRingBand(amnesia, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1010, 120f);
		system.addRingBand(amnesia, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1115, 120f);
		system.addRingBand(amnesia, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1230, 120f);
		system.addAsteroidBelt(amnesia, 0, 1050, 400, 300, 300, Terrain.RING, "Entrails");

		SectorEntityToken relay = system.addCustomEntity("relay", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"luddic_church"); // faction
		relay.setCircularOrbitPointingDown(star, 100+50, 6900, 500);

		SectorEntityToken buoy = system.addCustomEntity("relay", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"sensor_array_makeshift", // type of object, defined in custom_entities.json
				"luddic_church"); // faction
		buoy.setCircularOrbitPointingDown(star, 100-50, 6900, 500);

		//JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Gaygan Jump-Point");
		JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("jumpPoint", "Inner Jump-Point");
		jumpPoint2.setCircularOrbit(star, -30, 8050, 800);
		system.addEntity(jumpPoint2);

		PlanetAPI sobriety = system.addPlanet("sobriety", star, "Sobriety", "toxic_cold", 55, 60, 11500, 1200);
		system.addRingBand(star, "misc", "rings_dust0", 1024f, 1, new Color(155, 155, 255), 2048f, 12500, 1000f, Terrain.RING, "Myraa's Remnants");
		//system.addRingBand(star, "misc", "rings_asteroids0", 1024f, 1, Color.white, 2048f, 13250, 1200f, null, null);
		//system.addRingBand(star, "misc", "rings_asteroids0", 1024f, 1, Color.white, 2048f, 13000, 1200f, null, null);
		//system.addAsteroidBelt(star, 1000, 13000, 2000, 400, 300, Terrain.ASTEROID_BELT, "Myraa's Remnants");
		//system.addAsteroidBelt(star, 1000, 12500, 2000, 400, 300, Terrain.ASTEROID_BELT, "Myraa's Remnants");

		system.autogenerateHyperspaceJumpPoints(true, true);

		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
