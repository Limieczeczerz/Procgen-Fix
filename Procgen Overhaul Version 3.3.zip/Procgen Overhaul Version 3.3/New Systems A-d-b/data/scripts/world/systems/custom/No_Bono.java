package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
//import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class No_Bono {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("No Bono");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background1.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("no_bono", // unique id for star
				StarTypes.WHITE_DWARF, // id in planets.json
				520f,		// radius (in pixels at default zoom)
				400, // extent of corona outside star
				1f, // solar wind burn level
				0f, // flare probability
				1f); // CR loss multiplier, good values are in the range of 1-5

		system.setLightColor(new Color(181, 29, 156)); // light color in entire system, affects all entities
		//system.setLightColor(new Color(230, 230, 255)); // light color in entire system, affects all entities

		PlanetAPI alone = system.addPlanet("alone", star, "Alone", "barren", 80, 100, 1800, 60);

		PlanetAPI planet_null = system.addPlanet("planet_null", star, "Null", "lava_minor", 210, 160, 3800, 120);
		//planet_null.setCustomDescriptionId("planet_null");

		SectorEntityToken null_lag = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						600f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						8f, // min asteroid radius
						12f, // max asteroid radius
						null)); // null for default name

		null_lag.setCircularOrbit(star, 210-80, 3800, 120);

		SectorEntityToken empty_1 = system.addCustomEntity("empty_1", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"comm_relay_makeshift", // type of object, defined in custom_entities.json
				"independent"); // faction
		empty_1.setCircularOrbitPointingDown(star, 210-80, 3800, 120);
		
			JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint_null", "Devoid");
			jumpPoint.setCircularOrbit(star, 210 + 80, 3800, 120);
			jumpPoint.setStandardWormholeToHyperspaceVisual();
			jumpPoint.setRelatedPlanet(planet_null);
			system.addEntity(jumpPoint);

		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 5000, 100, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 5050, 190, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 5250, 240, Terrain.RING, null);

		PlanetAPI forbidden = system.addPlanet("forbidden", star, "Forbidden", "ice_giant", 120, 260, 8000, 300);
		PlanetAPI fameless = system.addPlanet("fameless", forbidden, "Fameless", "toxic_cold", 120, 60, 720, 32);
		//fameless.setCustomDescriptionId("planet_fameless");

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
				1, 1, // min/max entities to add
				10000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds

		StarSystemGenerator.addSystemwideNebula(system, StarAge.YOUNG);

		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
		
	
}
