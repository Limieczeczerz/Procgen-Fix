package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.ids.Submarkets;

import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
public class Bzabzen {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Bzabzen");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background4.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		// Al Gebbar, "the giant"
		PlanetAPI star = system.initStar("bzabzen", // unique id for this star
				StarTypes.ORANGE, // id in planets.json
				750f,		// radius (in pixels at default zoom)
				800, // extent of corona outside star
				10f, // solar wind burn level
				2f, // flare probability
				3f); // CR loss multiplier, good values are in the range of 1-5
		
		//system.setLightColor(new Color(202, 135, 150)); // light color in entire system, affects all entities
		system.setLightColor(new Color(255, 190, 150)); // light color in entire system, affects all entities

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Voronira Entry-point");
		jumpPoint.setCircularOrbit(system.getEntityById("bzabzen"), 34, 1800, 90);
		jumpPoint.setStandardWormholeToHyperspaceVisual();
		//jumpPoint.setRelatedPlanet(bourbon);
		system.addEntity(jumpPoint);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
				2, 2, // min/max entities to add
				3000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds

		PlanetAPI bourbon = system.addPlanet("bourbon", star, "Bourbon", "terran", 35, 170, 7000, 255);
		bourbon.setCustomDescriptionId("planet_bourbon");
		bourbon.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		bourbon.getSpec().setGlowColor(new Color(197,34,245,255));
		bourbon.getSpec().setUseReverseLightForGlow(true);
		bourbon.applySpecChanges();
			PlanetAPI boboon = system.addPlanet("boboon", bourbon, "Boboon", "barren2", 40, 50, 500, 33);
			boboon.setCustomDescriptionId("planet_boboon");

		SectorEntityToken don_eladio_extra = system.addCustomEntity(null, null, "nav_buoy", Factions.PERSEAN);
		don_eladio_extra.setCircularOrbitPointingDown(star, 50+40, 8400, 420);
			
		SectorEntityToken don_eladio = system.addCustomEntity(null, null, "comm_relay_makeshift", Factions.PERSEAN);
		don_eladio.setCircularOrbitPointingDown(star, 50-40, 9400, 590);

		PlanetAPI gigamad = system.addPlanet("gigamad", star, "Gigamad", "gas_giant", 50, 340, 9400, 590);
			system.addRingBand(gigamad, "misc", "rings_special0", 256f, 1, new Color(240,225,255,255), 256f, 800, 200f, Terrain.RING, null);
			system.addRingBand(gigamad, "misc", "rings_special0", 256f, 1, new Color(240,240,240,255), 256f, 1000, 200f, Terrain.RING, null);

			SectorEntityToken onion_ring_station = system.addCustomEntity("onion_ring_station", "Derakh Sanctuarium", "station_side06", "neutral");
			onion_ring_station.setCircularOrbitPointingDown(system.getEntityById("gigamad"), -50, 1000, 50);
			onion_ring_station.setCustomDescriptionId("station_onion_ring");
			onion_ring_station.setInteractionImage("illustrations", "abandoned_station2");
			Misc.setAbandonedStationMarket("onion_ring_station_market", onion_ring_station);

		PlanetAPI servant_zero = system.addPlanet("servant_zero", star, "Servant Zero", "ice_giant", 50, 270, 12500, 680);
			PlanetAPI bonnibel = system.addPlanet("bonnibel", servant_zero, "Bonnibel", "cryovolcanic", -150, 60, 500, 20);
			system.addRingBand(servant_zero, "misc", "rings_ice0", 256f, 1, new Color(255,225,200,255), 256f, 800, 200f, Terrain.RING, null);
			PlanetAPI marceline = system.addPlanet("marceline", servant_zero, "Marceline", "rocky_ice", 120, 75, 1000, 40);

			
		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
