package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;

import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;

public class Thule {

	public void generate(SectorAPI sector) {	
		
		StarSystemAPI system = sector.createStarSystem("Thule");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI thule_star = system.initStar("thule", // unique id for this star
												"star_white",  // id in planets.json
												600f, 		  // radius (in pixels at default zoom)
												600, // corona
												4f, // solar wind burn level
												0.5f, // flare probability
												1.5f); // CR loss multiplier, good values are in the range of 1-5

		system.setLightColor(new Color(200, 230, 255)); // light color in entire system, affects all entities
		
		PlanetAPI hekla = system.addPlanet("hekla", thule_star, "Hekla", "toxic", 0, 160, 1870, 90);
		hekla.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
		hekla.getSpec().setGlowColor( new Color(255,190,10,100) );
		hekla.getSpec().setUseReverseLightForGlow(true);
		hekla.getSpec().setPlanetColor( new Color(255, 235, 170,255) );
		hekla.applySpecChanges();
		
		SectorEntityToken array1 = system.addCustomEntity(null, null, "sensor_array", Factions.PERSEAN);
		array1.setCircularOrbitPointingDown( thule_star, 60, 1870, 90);

		system.addAsteroidBelt(thule_star, 90, 2600, 350, 100, 60, Terrain.ASTEROID_BELT,  "Earls of Lade");
		system.addRingBand(thule_star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 2500, 105f, null, null);
		system.addRingBand(thule_star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 2620, 115f, null, null);
		system.addRingBand(thule_star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 2700, 105f, null, null);

		PlanetAPI kazeron = system.addPlanet("kazeron", thule_star, "Kazeron", "barren_castiron", 90, 130, 3200, 225);
		kazeron.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "sindria"));
		kazeron.getSpec().setGlowColor( new Color(240,215,117,255) );
		kazeron.getSpec().setUseReverseLightForGlow(true);
		kazeron.getSpec().setPitch(-15f);
		kazeron.getSpec().setTilt(20f);
		kazeron.applySpecChanges();
		kazeron.setCustomDescriptionId("planet_kazeron");
		kazeron.setInteractionImage("illustrations", "kazeron");

		system.addAsteroidBelt(thule_star, 90, 3900, 300, 200, 80, Terrain.ASTEROID_BELT,  "The Ingwin");
		system.addRingBand(thule_star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 3800, 205f, null, null);
		system.addRingBand(thule_star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 3920, 215f, null, null);
		system.addRingBand(thule_star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 4000, 205f, null, null);

		//SectorEntityToken kazeronStation = system.addCustomEntity("kazeron_station", "Kazeron Star Command", "station_midline2", Factions.PERSEAN);
		//kazeronStation.setCircularOrbitPointingDown( kazeron, 0, 250, 30);
		//kazeronStation.setInteractionImage("illustrations", "orbital");

		PlanetAPI draugr = system.addPlanet("draugr", kazeron, "Draugr", "barren-bombarded", 0, 50, 320, 24);
		draugr.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
		draugr.getSpec().setGlowColor( new Color(255,220,50,35) );
		draugr.getSpec().setUseReverseLightForGlow(true);
		draugr.getSpec().setPitch(-90f);
		draugr.getSpec().setTilt(90f);
		draugr.getSpec().setPlanetColor( new Color(255, 245, 230,255) );
		draugr.applySpecChanges();

		// Kazeron jump-point
		JumpPointAPI jumpPoint1 = Global.getFactory().createJumpPoint("thule_jump", "Thule Jump-point");
		jumpPoint1.setCircularOrbit( system.getEntityById("thule"), 30, 3200, 225);
		jumpPoint1.setRelatedPlanet(kazeron);
		system.addEntity(jumpPoint1);

		SectorEntityToken kazeronL1 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						500f, // max radius
						5, // min asteroid count
						10, // max asteroid count
						10f, // min asteroid radius
						12f, // max asteroid radius
						null)); // null for default name
		kazeronL1.setCircularOrbit(thule_star, 30, 3200, 225);

		// Kazeron Relay - L5 (behind)
		SectorEntityToken kazeron_relay = system.addCustomEntity("kazeron_relay", "Kazeron Relay",  "comm_relay", Factions.PERSEAN);
		kazeron_relay.setCircularOrbitPointingDown( thule_star, 150, 3200, 225);

		SectorEntityToken kazeronL2 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						500f, // max radius
						5, // min asteroid count
						10, // max asteroid count
						10f, // min asteroid radius
						12f, // max asteroid radius
						null)); // null for default name
		kazeronL2.setCircularOrbit(thule_star, 150, 3200, 225);

		system.addAsteroidBelt(thule_star, 90, 5880, 400, 450, 300, Terrain.RING,  "Inged's Crown");
		system.addRingBand(thule_star, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 5800, 405f, null, null);
		system.addRingBand(thule_star, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 5900, 305f, null, null);
		system.addRingBand(thule_star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 6020, 365f, null, null);

		PlanetAPI eldfell = system.addPlanet("eldfell", thule_star, "Eldfell", "lava_minor", 180, 140, 6400, 560);
		eldfell.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
		eldfell.getSpec().setGlowColor( new Color(250,220,210,45) );
		eldfell.getSpec().setUseReverseLightForGlow(true);
		eldfell.getSpec().setPitch(20f);
		eldfell.getSpec().setTilt(30f);
		eldfell.getSpec().setPlanetColor( new Color(220, 245, 255,255) );
		eldfell.getSpec().setAtmosphereThicknessMin(16);
		eldfell.getSpec().setAtmosphereThickness(0.14f);
		eldfell.getSpec().setAtmosphereColor( new Color(230,245,255,30) );
		eldfell.applySpecChanges();
		eldfell.setCustomDescriptionId("planet_eldfell");

		//Eldfell jump-point
		JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("eldfell_jump", "Outer System Jump-point");
		jumpPoint2.setCircularOrbit(system.getEntityById("thule"), 180+60, 6400, 520);
		jumpPoint2.setRelatedPlanet(eldfell);
		system.addEntity(jumpPoint2);

		PlanetAPI laki = system.addPlanet("laki", thule_star, "Laki", "barren3", 0, 30, 8400, 600);

		system.addAsteroidBelt(thule_star, 90, 8550, 250, 490, 310, Terrain.ASTEROID_BELT,  "Hama's Band");
		system.addRingBand(thule_star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 8500, 405f, null, null);
		system.addRingBand(thule_star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 8600, 495f, null, null);

		PlanetAPI hengill = system.addPlanet("hengill", thule_star, "Hengill", "frozen2", 180, 110, 9700, 560);

		// Gate of Thule
		SectorEntityToken gate = system.addCustomEntity("thule_gate", // unique id
				"Gate of Thule", // name - if null, defaultName from custom_entities.json will be used
				"inactive_gate", // type of object, defined in custom_entities.json
				null); // faction

		gate.setCircularOrbit(thule_star, 180+60, 9700, 560);
				
		SectorEntityToken eldfell_stable = system.addCustomEntity(null, null, "stable_location", "neutral");
		eldfell_stable.setCircularOrbitPointingDown( thule_star, 180-60 , 9700, 560);
				
		system.addAsteroidBelt(thule_star, 90, 10700, 600, 700, 300, Terrain.RING,  "Garmund's Ring");
		system.addRingBand(thule_star, "misc", "rings_ice0", 256f, 1, new Color(230,240,255,255), 512f, 10600, 750, null, null);
		system.addRingBand(thule_star, "misc", "rings_ice0", 256f, 2, Color.white, 512f, 10750, 765, null, null);
		system.addRingBand(thule_star, "misc", "rings_ice0", 256f, 2, Color.white, 512f, 10750, 785, null, null);
		system.addRingBand(thule_star, "misc", "rings_ice0", 256f, 1, new Color(230,240,255,255), 512f, 10870, 795, null, null);
		
		PlanetAPI morn = system.addPlanet("morn", thule_star, "Morn", "ice_giant", 90, 240, 11500, 890);
		morn.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
		morn.getSpec().setGlowColor( new Color(235,250,150,45) );
		morn.getSpec().setUseReverseLightForGlow(true);
		morn.getSpec().setPitch(-5f);
		morn.getSpec().setTilt(20f);
		morn.getSpec().setPlanetColor( new Color(155, 155, 155, 255) );
		morn.applySpecChanges();
		
			// Morn L5 cloud
			SectorEntityToken nebula1 = system.addTerrain(Terrain.NEBULA, new BaseTiledTerrain.TileParams(
					"      " +
					"  xx x" +
					" xxxxx" +
					"xxx xx" +
					" xxx  " +
					"  xxx ",
					6, 6, // size of the nebula grid, should match above string
					"terrain", "nebula", 4, 4, "Morn L5 Cloud"));
			nebula1.getLocation().set(morn.getLocation().x + 1000f, morn.getLocation().y);
			nebula1.setCircularOrbit(thule_star,
										morn.getCircularOrbitAngle() - 60f,
										morn.getCircularOrbitRadius(), 
										390);
			
			// Morn L4 cloud
			SectorEntityToken nebula2 = system.addTerrain(Terrain.NEBULA, new BaseTiledTerrain.TileParams(
					"  x xx" +
					" xxx  " +
					"   xx " +
					"xxxxxx" +
					"  xx  " +
					" x    ",
					6, 6, // size of the nebula grid, should match above string
					"terrain", "nebula", 4, 4, "Morn L4 Cloud"));
			nebula2.getLocation().set(morn.getLocation().x - 1000f, morn.getLocation().y);
			nebula2.setCircularOrbit(thule_star,
									morn.getCircularOrbitAngle() + 60f,
									morn.getCircularOrbitRadius(), 
									390);
		
		PlanetAPI skoll = system.addPlanet("skoll", thule_star, "Skoll", "ice_giant", 270, 260, 14450, 920);
		//skoll.setCustomDescriptionId("planet_skoll");
		skoll.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		skoll.getSpec().setGlowColor( new Color(50,255,250,75) );
		skoll.getSpec().setUseReverseLightForGlow(true);
		skoll.getSpec().setPitch(150f);
		skoll.getSpec().setTilt(80f);
		skoll.getSpec().setPlanetColor( new Color(150,150,150,255) );
		skoll.applySpecChanges();
		
			SectorEntityToken skoll_magfield = system.addTerrain(Terrain.MAGNETIC_FIELD,
			new MagneticFieldParams(400, // terrain effect band width
					500, // terrain effect middle radius
					skoll, // entity that it's around
					300, // visual band start
					700, // visual band end
					new Color(50, 20, 100, 50), // base color
					2f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
					new Color(90, 180, 40),
					new Color(130, 145, 90),
					new Color(165, 110, 145), 
					new Color(95, 55, 160), 
					new Color(45, 0, 130),
					new Color(20, 0, 130),
					new Color(10, 0, 150)));
			skoll_magfield.setCircularOrbit(skoll, 0, 0, 20);

		//SectorEntityToken kazeronStation = system.addCustomEntity("kazeron_station", "Kazeron Star Command", "station_midline2", Factions.PERSEAN);
		//kazeronStation.setCircularOrbitPointingDown( kazeron, 0, 250, 30);
		//kazeronStation.setInteractionImage("illustrations", "orbital");

		SectorEntityToken thule_pirate_station = system.addCustomEntity("thule_pirate_station",
				"Thulian Raider Base", "station_side02", "pirates");

		//SectorEntityToken thule_pirate_station = system.addCustomEntity("thule_pirate_station", "Thulian Raider Base", "station_midline2", "pirates");
		thule_pirate_station.setCircularOrbitPointingDown(system.getEntityById("skoll"), 240, 790, 38);
		thule_pirate_station.setCustomDescriptionId("station_thulian_raiders");
		thule_pirate_station.setInteractionImage("illustrations", "pirate_station");

		system.addRingBand(skoll, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 790, 38f, Terrain.RING, null);
		system.addRingBand(skoll, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 810, 35f, Terrain.RING, null);
		system.addRingBand(skoll, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 830, 45f, Terrain.RING, null);
		
		system.autogenerateHyperspaceJumpPoints(true, true);
	}
}
