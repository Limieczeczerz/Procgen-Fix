package data.scripts.world.systems;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Entities;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.StarSystemType;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain.RingParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldSource;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;

public class Magec {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Magec");
		system.setType(StarSystemType.BINARY_FAR);
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background2.jpg");

		PlanetAPI star = system.initStar("magec", // unique id for this star
				StarTypes.BLUE_GIANT, // id in planets.json
				900f,		// radius (in pixels at default zoom)
				500); // corona radius, from star edge

		system.setLightColor(new Color(225, 245, 255)); // light color in entire system, affects all entities
		
		PlanetAPI magec1 = system.addPlanet("chaxiraxi", star, "Chaxiraxi", "fire_giant", 50, 410, 2275, 80);
		magec1.getSpec().setPlanetColor(new Color(50,100,255,255));
		magec1.getSpec().setAtmosphereColor(new Color(120,130,100,150));
		magec1.getSpec().setCloudColor(new Color(195,230,255,200));
		magec1.getSpec().setIconColor(new Color(120,130,100,255));
		magec1.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		magec1.getSpec().setGlowColor(new Color(235,38,8,145));
		magec1.getSpec().setUseReverseLightForGlow(true);
		magec1.getSpec().setAtmosphereThickness(0.5f);
		magec1.applySpecChanges();
		magec1.setCustomDescriptionId("planet_chaxiraxi");

		system.addCorona(magec1, Terrain.CORONA_AKA_MAINYU,
				300f, // radius outside planet
				5f, // burn level of "wind"
				0f, // flare probability
				1f // CR loss mult while in it
		);
		
		SectorEntityToken magec1_field = system.addTerrain(Terrain.MAGNETIC_FIELD,
						new MagneticFieldParams(400f, // terrain effect band width
						600, // terrain effect middle radius
						magec1, // entity that it's around
						410f, // visual band start
						810f, // visual band end
						new Color(107, 95, 142, 30), // base color
						2f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
						new Color(97, 92, 109, 30),
						new Color(170, 130, 160, 50),
						new Color(71, 53, 62, 90),
						new Color(71, 63, 66, 40),
						new Color(71, 63, 66, 55),
						new Color(75, 0, 160), 
						new Color(127, 0, 255)
						));
			magec1_field.setCircularOrbit(magec1, 0, 0, 100);

		
		// And herrrrre's Achaman
		PlanetAPI magec3 = system.addPlanet("achaman", star, "Achaman", "star_white", 45, 200, 22000, 1420);
		system.setSecondary(magec3);
		system.addCorona(magec3, 600, 5f, 0.5f, 2f); // it's a very docile star.

		system.setSecondary(magec3);
		system.setType(StarSystemType.BINARY_FAR);
		
		SectorEntityToken achaman_buoy = system.addCustomEntity("achaman_relay", // unique id
				 "Achaman Relay", // name - if null, defaultName from custom_entities.json will be used
				 "nav_buoy", // type of object, defined in custom_entities.json
				 "tritachyon"); // faction
		
		achaman_buoy.setCircularOrbitPointingDown(magec3, 22, 1500, 100);
		
		PlanetAPI magec3a = system.addPlanet("tibicena", magec3, "Tibicena", "barren-bombarded", 200, 140, 2200, 160);
		magec3a.setCustomDescriptionId("planet_tibicena");
		magec3a.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		magec3a.getSpec().setGlowColor(new Color(227,188,184,255));
		magec3a.getSpec().setUseReverseLightForGlow(true);
		magec3a.applySpecChanges();
		
			SectorEntityToken achaman_station = system.addCustomEntity("achaman_enterprise_station", 
																		"Achaman Enterprise Station",
																		"station_side04",
																		"tritachyon");
			
			achaman_station.setCircularOrbitPointingDown(system.getEntityById("tibicena"), 90, 250, 40);
			achaman_station.setCustomDescriptionId("station_achaman_enterprise");
			achaman_station.setInteractionImage("illustrations", "hound_hangar");
			
			
		// Asteroid belts; which I guess we're not doing in quite proper order.

		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 3200, 320f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 3300, 200f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 3400, 260f);
		system.addAsteroidBelt(star, 150, 3300, 600, 150, 250, Terrain.ASTEROID_BELT, "Guayota's Disk");

		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 4000, 320f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 4100, 240f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 4200, 320f);
		system.addAsteroidBelt(star, 150, 4100, 300, 200, 300, Terrain.ASTEROID_BELT, "Guayota's Disk");

		system.addRingBand(star, "misc", "rings_dust0", 256f, 3, Color.white, 256f, 4300, 280f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 4400, 180f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 4500, 220f);
		system.addAsteroidBelt(star, 150, 4400, 600, 210, 300, Terrain.ASTEROID_BELT, "Guayota's Disk");

		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 4500, 400f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 4600, 280f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 1, Color.white, 256f, 4700, 320f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 4800, 360f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 4900, 360f);
		system.addAsteroidBelt(star, 200, 4700, 600, 220, 300, Terrain.ASTEROID_BELT, "Guayota's Disk");

		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 6500, 500f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 6600, 380f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 6700, 420f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 6800, 460f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 6900, 460f);
		system.addAsteroidBelt(star, 200, 6700, 600, 300, 300, Terrain.ASTEROID_BELT, "Guayota's Disk");

		system.addRingBand(star, "misc", "rings_special0", 256f, 0, Color.white, 256f, 8500, 500f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 8600, 380f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 1, Color.white, 256f, 8700, 420f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 8800, 460f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 8900, 460f);
		system.addAsteroidBelt(star, 200, 8700, 600, 400, 400, Terrain.ASTEROID_BELT, "Guayota's Disk");

		system.addRingBand(star, "misc", "rings_special0", 256f, 0, Color.white, 256f, 8100, 520f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 8200, 400f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 1, Color.white, 256f, 8300, 440f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 8400, 480f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 8500, 480f);
		system.addAsteroidBelt(star, 200, 8300, 600, 420, 500, Terrain.ASTEROID_BELT, "Guayota's Disk");

		system.addRingBand(star, "misc", "rings_special0", 256f, 0, Color.white, 256f, 9500, 550f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 9600, 430f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 1, Color.white, 256f, 9700, 470f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 9800, 520f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 9900, 520f);
		system.addAsteroidBelt(star, 200, 9700, 600, 450, 500, Terrain.ASTEROID_BELT, "Guayota's Disk");


		//SectorEntityToken pirateStation = system.addOrbitalStation("kantas_den", star, 240, 4250, 160, "Kanta's Den", "pirates");
		SectorEntityToken pirateStation = system.addCustomEntity("kantas_den", "Kanta's Den", "station_side06", "pirates");
		pirateStation.setCustomDescriptionId("station_kantas_den");
		pirateStation.setInteractionImage("illustrations", "pirate_station");
		pirateStation.setCircularOrbitWithSpin(star, 220, 4250, 160, 6, 10);

		// Guayota Relay - L5 (behind); well, okay, not quite the L5. But whatever.
		SectorEntityToken guayota_relay = system.addCustomEntity("guayota_relay", // unique id
				"Guayota Relay", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay_makeshift", // type of object, defined in custom_entities.json
				"neutral"); // faction

		guayota_relay.setCircularOrbitPointingDown( star, 150, 5900, 240);

		PlanetAPI moneiba = system.addPlanet("moneiba", star, "Moneiba", "toxic", 90, 180, 5900, 240);

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("maxios_jump_point", "Moneiba Jump-point");
		OrbitAPI orbit = Global.getFactory().createCircularOrbit(star, 30, 5900, 240);
		jumpPoint.setOrbit(orbit);
		jumpPoint.setRelatedPlanet(moneiba);
		jumpPoint.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumpPoint);

		//SectorEntityToken civilianStation = system.addOrbitalStation("new_maxios", star, 0, 3900, 160, "New Maxios", "independent");
		SectorEntityToken civilianStation = system.addCustomEntity("new_maxios", "Nova Maxios", "station_side07", "independent");
		civilianStation.setCustomDescriptionId("station_new_maxios");
		civilianStation.setInteractionImage("illustrations", "cargo_loading");
		civilianStation.setCircularOrbitWithSpin(star, 45-45, 7500, 360, 4, 10);

		SectorEntityToken base_home_asteroid = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						500f, // min radius
						600f, // max radius
						40, // min asteroid count
						60, // max asteroid count
						6f, // min asteroid radius
						12f, // max asteroid radius
						null)); // null for default name

		base_home_asteroid.setCircularOrbit(star, 45-45, 7500, 360);

		// Magec Gate - counter-orbit to Achaman
		SectorEntityToken gate = system.addCustomEntity("magec_gate", // unique id
				"Magec Gate", // name - if null, defaultName from custom_entities.json will be used
				Entities.INACTIVE_GATE, // type of object, defined in custom_entities.json
				null); // faction
		gate.setCircularOrbit(star, 45+45, 7500, 360);

		DebrisFieldParams params = new DebrisFieldParams(
				500f, // field radius - should not go above 1000 for performance reasons
				-1f, // density, visual - affects number of debris pieces
				10000000f, // duration in days
				0f); // days the field will keep generating glowing pieces
		params.source = DebrisFieldSource.MIXED;
		params.baseSalvageXP = 250; // base XP for scavenging in field
		SectorEntityToken debrisNextToGate = Misc.addDebrisField(system, params, StarSystemGenerator.random);
		debrisNextToGate.setSensorProfile(null);
		debrisNextToGate.setDiscoverable(null);
		debrisNextToGate.setCircularOrbit(gate, 0f, 0f, 100f);
		debrisNextToGate.setId("magec_debrisNextToGate");

		PlanetAPI magec2 = system.addPlanet("maxios", star, "Maxios", "barren", 45, 140, 7500, 360);
		Misc.initConditionMarket(magec2);
		magec2.getMarket().addCondition(Conditions.DECIVILIZED);
		magec2.getMarket().addCondition(Conditions.RUINS_EXTENSIVE);
		magec2.getMarket().getFirstCondition(Conditions.RUINS_EXTENSIVE).setSurveyed(true);

		magec2.getMarket().addCondition(Conditions.METEOR_IMPACTS);
		magec2.getMarket().addCondition(Conditions.ORE_MODERATE);
		magec2.getMarket().addCondition(Conditions.RARE_ORE_SPARSE);
		magec2.getMarket().addCondition(Conditions.HOT);
		magec2.getMarket().addCondition(Conditions.THIN_ATMOSPHERE);

		magec2.setCustomDescriptionId("planet_maxios");
		magec2.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		magec2.getSpec().setGlowColor(new Color(255,245,235,255));
		magec2.getSpec().setUseReverseLightForGlow(true);
		magec2.getSpec().setAtmosphereThicknessMin(25);
		magec2.getSpec().setAtmosphereThickness(0.2f);
		magec2.getSpec().setAtmosphereColor( new Color(80,90,100,120) );
		magec2.applySpecChanges();

		PlanetAPI achuguayo = system.addPlanet("achuguayo", star, "Achuguayo", "gas_giant", 230, 280, 11400, 740);
		achuguayo.getSpec().setPlanetColor(new Color(135, 110, 55,255));
		achuguayo.getSpec().setCloudColor(new Color(135, 110, 55,255));
		//achuguayo.getSpec().setIconColor(new Color(15, 175, 225,255));
		achuguayo.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
		achuguayo.getSpec().setGlowColor(new Color(135, 110, 55,145));
		achuguayo.getSpec().setUseReverseLightForGlow(true);
		achuguayo.getSpec().setPitch(-5f);
		achuguayo.getSpec().setTilt(20f);
		achuguayo.applySpecChanges();

		PlanetAPI tanit = system.addPlanet("tanit", achuguayo, "Tanit", "cryovolcanic", 230, 60, 400, 20);
		PlanetAPI astarte = system.addPlanet("astarte", achuguayo, "Astarte", "frozen3", 230, 80, 900, 45);

		JumpPointAPI outer_system_jump_point = Global.getFactory().createJumpPoint("outer_system_jump_point", "Outer System Jump-point");
		OrbitAPI orbit2 = Global.getFactory().createCircularOrbit(star, 230-30, 11400, 740);
		outer_system_jump_point.setOrbit(orbit2);
		outer_system_jump_point.setStandardWormholeToHyperspaceVisual();
		system.addEntity(outer_system_jump_point);

		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 13400, 750f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 13600, 630f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 1, Color.white, 256f, 13700, 670f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 13800, 720f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 2, Color.white, 256f, 13900, 720f);
		system.addAsteroidBelt(star, 200, 13700, 640, 650, 500, Terrain.ASTEROID_BELT, "Guayota's Disk");

		system.addRingBand(star, "misc", "rings_special0", 256f, 0, Color.white, 256f, 13800, 760f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 14000, 640f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 1, Color.white, 256f, 14100, 680f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 14200, 730f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 14300, 730f);
		system.addAsteroidBelt(star, 200, 14100, 640, 660, 520, Terrain.ASTEROID_BELT, "Guayota's Disk");

		system.addRingBand(star, "misc", "rings_special0", 256f, 0, Color.white, 256f, 14800, 740f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 15000, 620f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 1, Color.white, 256f, 15100, 660f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 15200, 740f);
		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 15300, 740f);
		system.addAsteroidBelt(star, 200, 15100, 640, 610, 540, Terrain.RING, "Guayota's Disk");
		
		//float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
		//		1, 2, // min/max entities to add
		//		15000, // radius to start adding at
		//		4, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
		//		true, // whether to use custom or system-name based names
		//		false); // whether to allow habitable worlds

		//StarSystemGenerator.addSystemwideNebula(system, StarAge.AVERAGE);

		system.autogenerateHyperspaceJumpPoints(true, true);
	}


}
