package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.ids.Submarkets;

import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
public class Bzabzen {

	public void generate(SectorAPI sector) {
		
		StarSystemAPI system = sector.createStarSystem("Bzabzen");
		LocationAPI hyper = Global.getSector().getHyperspace();
		
		system.setBackgroundTextureFilename("graphics/backgrounds/background4.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		// Al Gebbar, "the giant"
		PlanetAPI star = system.initStar("bzabzen", // unique id for this star
				StarTypes.ORANGE, // id in planets.json
				750f,		// radius (in pixels at default zoom)
				800, // extent of corona outside star
				10f, // solar wind burn level
				2f, // flare probability
				3f); // CR loss multiplier, good values are in the range of 1-5
		
		//system.setLightColor(new Color(202, 135, 150)); // light color in entire system, affects all entities
		//system.setLightColor(new Color(255, 190, 150)); // light color in entire system, affects all entities
		system.setLightColor(new Color(255, 235, 205)); // light color in entire system, affects all entities

		//JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Voronira Entry-point");
		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Inner System Jump-point");
		jumpPoint.setCircularOrbit(system.getEntityById("bzabzen"), 34, 1800, 90);
		jumpPoint.setStandardWormholeToHyperspaceVisual();
		//jumpPoint.setRelatedPlanet(bourbon);
		system.addEntity(jumpPoint);

		//float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
		//		2, 2, // min/max entities to add
		//		3000, // radius to start adding at
		//		0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
		//		true, // whether to use custom or system-name based names
		//		false); // whether to allow habitable worlds

		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 2200, 220f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 2300, 100f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 2400, 160f);
		system.addAsteroidBelt(star, 150, 2300, 600, 150, 250, Terrain.ASTEROID_BELT, "Anger of Bismungold");
		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 3000, 120f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 3100, 140f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 3200, 120f);
		system.addAsteroidBelt(star, 150, 3100, 300, 200, 300, Terrain.ASTEROID_BELT, "Anger of Bismungold");
		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 3500, 160f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 3600, 180f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 3700, 160f);
		system.addAsteroidBelt(star, 150, 3600, 300, 200, 300, Terrain.ASTEROID_BELT, "Anger of Bismungold");

		PlanetAPI crackler = system.addPlanet("crackler", star, "Crackler", "rocky_metallic", 35, 150, 4500, 255);

		JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("jumpPoint", "Outer System Jump-point");
		jumpPoint2.setCircularOrbit(system.getEntityById("bzabzen"), 35+60, 4500, 255);
		jumpPoint2.setStandardWormholeToHyperspaceVisual();
		jumpPoint2.setRelatedPlanet(crackler);
		system.addEntity(jumpPoint2);

		PlanetAPI bourbon = system.addPlanet("bourbon", star, "Bourbon", "terran", 35, 120, 6000, 355);
		bourbon.setCustomDescriptionId("planet_bourbon");
		bourbon.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		bourbon.getSpec().setGlowColor(new Color(197,34,245,255));
		bourbon.getSpec().setUseReverseLightForGlow(true);
		bourbon.applySpecChanges();
			PlanetAPI boboon = system.addPlanet("boboon", bourbon, "Boboon", "barren2", 40, 50, 400, 33);
			boboon.setCustomDescriptionId("planet_boboon");

		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, new Color(200, 200, 255), 256f, 7000, 410f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 0, new Color(200, 200, 255), 256f, 7200, 420f, Terrain.RING, null);

		SectorEntityToken don_eladio_extra = system.addCustomEntity(null, null, "nav_buoy", Factions.PERSEAN);
		don_eladio_extra.setCircularOrbitPointingDown(star, 50+40, 8400, 590);
			
		SectorEntityToken don_eladio = system.addCustomEntity(null, null, "comm_relay_makeshift", Factions.PERSEAN);
		don_eladio.setCircularOrbitPointingDown(star, 50-40, 9400, 590);

		PlanetAPI gigamad = system.addPlanet("gigamad", star, "Gigamad", "gas_giant", 50, 340, 9400, 590);
			system.addRingBand(gigamad, "misc", "rings_special0", 256f, 1, new Color(240,225,255,255), 256f, 800, 200f, Terrain.RING, null);
			system.addRingBand(gigamad, "misc", "rings_special0", 256f, 1, new Color(240,240,240,255), 256f, 1000, 200f, Terrain.RING, null);

			SectorEntityToken onion_ring_station = system.addCustomEntity("onion_ring_station", "Derakh Sanctuarium", "station_side06", "neutral");
			onion_ring_station.setCircularOrbitPointingDown(system.getEntityById("gigamad"), -50, 1000, 50);
			onion_ring_station.setCustomDescriptionId("station_onion_ring");
			onion_ring_station.setInteractionImage("illustrations", "abandoned_station2");
			Misc.setAbandonedStationMarket("onion_ring_station_market", onion_ring_station);

		PlanetAPI servant_zero = system.addPlanet("servant_zero", star, "Servant Zero", "ice_giant", 50, 270, 12500, 680);
			PlanetAPI bonnibel = system.addPlanet("bonnibel", servant_zero, "Bonnibel", "cryovolcanic", -150, 60, 500, 20);
			system.addRingBand(servant_zero, "misc", "rings_ice0", 256f, 1, new Color(255,225,200,255), 256f, 800, 200f, Terrain.RING, null);
			PlanetAPI marceline = system.addPlanet("marceline", servant_zero, "Marceline", "rocky_ice", 120, 75, 1000, 40);

		SectorEntityToken servant_zero_L1 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						500f, // min radius
						800f, // max radius
						10, // min asteroid count
						20, // max asteroid count
						5f, // min asteroid radius
						15f, // max asteroid radius
						null)); // null for default name
		servant_zero_L1.setCircularOrbit(star, 50-50, 12500, 680);
		PlanetAPI hambo = system.addPlanet("hambo", star, "Hambo", "barren", 50-50, 75, 12500, 680);

		SectorEntityToken servant_zero_L2 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						500f, // min radius
						800f, // max radius
						10, // min asteroid count
						20, // max asteroid count
						5f, // min asteroid radius
						15f, // max asteroid radius
						null)); // null for default name
		servant_zero_L2.setCircularOrbit(star, 50+50, 12500, 680);
		SectorEntityToken don_eladio5 = system.addCustomEntity(null, null, "stable_location", Factions.NEUTRAL);
		don_eladio5.setCircularOrbitPointingDown(star, 50+50, 12500, 680);

		PlanetAPI gonarch = system.addPlanet("gonarch", star, "Gonarch", "cryovolcanic", 35, 30, 14000, 755);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, new Color(200, 200, 255), 256f, 14100, 810f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, new Color(200, 200, 255), 256f, 14200, 820f, Terrain.RING, null);
			
		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
