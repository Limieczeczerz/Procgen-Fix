package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.StarSystemType;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;


import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.terrain.StarCoronaTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.StarCoronaTerrainPlugin.CoronaParams;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
public class Abaddon {

	public void generate(SectorAPI sector) {

		StarSystemAPI system = sector.createStarSystem("Abaddon");
		LocationAPI hyper = Global.getSector().getHyperspace();

		PlanetAPI star = system.initStar("abaddon", "nebula_center_young", 0f, 1000);
		StarCoronaTerrainPlugin coronaPlugin = Misc.getCoronaFor(star);
		system.removeEntity(coronaPlugin.getEntity());

		system.getCenter().addTag(Tags.AMBIENT_LS);
		StarSystemGenerator.addSystemwideNebula(system, StarAge.YOUNG);
		system.removeEntity(star);
		system.setType(StarSystemType.NEBULA);

		system.setLightColor(new Color(111, 129, 160)); // light color in entire system, affects all entities

		PlanetAPI lost_student = system.addPlanet("lost_student", star, "Lost Student", "ice_giant", 400, 360, 1800, 200);
		PlanetAPI follower = system.addPlanet("follower", lost_student, "Follower", "barren-bombarded", 5, 90, 800, 42);
		follower.setCustomDescriptionId("planet_follower");
		follower.setInteractionImage("illustrations", "urban00");

		//follower.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		//follower.getSpec().setGlowColor(new Color(245,127,91,255));
		//follower.getSpec().setUseReverseLightForGlow(true);

		SectorEntityToken death_field1 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						300f, // min radius
						600f, // max radius
						20, // min asteroid count
						24, // max asteroid count
						5f, // min asteroid radius
						10f, // max asteroid radius
						null)); // null for default name
		death_field1.setCircularOrbitPointingDown(star, 400-80, 1800, 200);
		SectorEntityToken barbed_wire = system.addCustomEntity("barbed_wire", "Barbed Wire", "station_side06", "persean");
		barbed_wire.setCircularOrbitWithSpin(star, 400-80, 1800, 200, 2, 5);
		barbed_wire.setCustomDescriptionId("station_barbed_wire");
		barbed_wire.setInteractionImage("illustrations", "hound_hangar");

		SectorEntityToken death_field2 = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						800f, // max radius
						12, // min asteroid count
						20, // max asteroid count
						8f, // min asteroid radius
						20f, // max asteroid radius
						null)); // null for default name
		death_field2.setCircularOrbitPointingDown(star, 400+80, 1800, 200);

		SectorEntityToken relay = system.addCustomEntity("relay", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"comm_relay_makeshift", // type of object, defined in custom_entities.json
				"persean"); // faction
		relay.setCircularOrbitPointingDown(star, 20, 13200, 570);

		SectorEntityToken buoy = system.addCustomEntity("buoy", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"nav_buoy_makeshift", // type of object, defined in custom_entities.json
				"persean"); // faction
		buoy.setCircularOrbitPointingDown(star, -40, 4400, 220);

		//PlanetAPI anexa = system.addPlanet("anexa", star, "Anexa", "toxic_cold", 300, 180, 5000, 320);

		JumpPointAPI dogtag = Global.getFactory().createJumpPoint("dogtag", "Inner System Jump-point");
		OrbitAPI orbit = Global.getFactory().createCircularOrbit(star, 300, 5000, 320);
		dogtag.setOrbit(orbit);
		dogtag.setStandardWormholeToHyperspaceVisual();
		system.addEntity(dogtag);
		
		//SectorEntityToken death_field3 = system.addTerrain(Terrain.ASTEROID_FIELD,
		//		new AsteroidFieldParams(
		//				200f, // min radius
		//				500f, // max radius
		//				20, // min asteroid count
		//				30, // max asteroid count
		//				8f, // min asteroid radius
		//				15f, // max asteroid radius
		//				null)); // null for default name
		//death_field3.setCircularOrbitPointingDown(star, 300, 5000, 320);

		SectorEntityToken array = system.addCustomEntity("array", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"sensor_array_makeshift", // type of object, defined in custom_entities.json
				"persean"); // faction
		array.setCircularOrbitPointingDown(star, 300-100, 5500, 350);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.YOUNG,
				1, 2, // min/max entities to add
				7000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				true); // whether to allow habitable worlds


			
		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
