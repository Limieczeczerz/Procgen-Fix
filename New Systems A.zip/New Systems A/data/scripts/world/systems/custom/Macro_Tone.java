package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.StarSystemType;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;

import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;


import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.terrain.StarCoronaTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.StarCoronaTerrainPlugin.CoronaParams;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
public class Macro_Tone {

	public void generate(SectorAPI sector) {

		StarSystemAPI system = sector.createStarSystem("Macro Tone");
		LocationAPI hyper = Global.getSector().getHyperspace();

		if (Global.getSettings().getBoolean("factionsClaimUnpopulatedCoreSystems")) {
			system.getMemoryWithoutUpdate().set(MemFlags.CLAIMING_FACTION, Factions.LUDDIC_CHURCH);
		}

		PlanetAPI star = system.initStar("macro_tone", "nebula_center_old", 0f, 1000);
		StarCoronaTerrainPlugin coronaPlugin = Misc.getCoronaFor(star);
		system.removeEntity(coronaPlugin.getEntity());

		system.getCenter().addTag(Tags.AMBIENT_LS);
		StarSystemGenerator.addSystemwideNebula(system, StarAge.OLD);
		system.removeEntity(star);
		system.setType(StarSystemType.NEBULA);

		system.setLightColor(new Color(122, 0, 133)); // light color in entire system, affects all entities

		PlanetAPI left_behind = system.addPlanet("left_behind", star, "Left Behind", "frozen2", 10, 150, 800, 40);
		Misc.initConditionMarket(left_behind);
		left_behind.getMarket().addCondition(Conditions.DECIVILIZED);
		left_behind.getMarket().addCondition(Conditions.RUINS_SCATTERED);
		left_behind.getMarket().getFirstCondition(Conditions.RUINS_SCATTERED).setSurveyed(true);
		left_behind.getMarket().addCondition(Conditions.ORE_MODERATE);
		left_behind.getMarket().addCondition(Conditions.VOLATILES_DIFFUSE);
		left_behind.getMarket().addCondition(Conditions.THIN_ATMOSPHERE);

		JumpPointAPI entrance_22 = Global.getFactory().createJumpPoint("entrance_22", "Entrance 22");
		entrance_22.setCircularOrbit(star, 80, 2500, 100);
		entrance_22.setRelatedPlanet(left_behind);
		entrance_22.setStandardWormholeToHyperspaceVisual();
		system.addEntity(entrance_22);

		SectorEntityToken relay = system.addCustomEntity("relay", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"independent"); // faction
		relay.setCircularOrbitPointingDown(star, -40, 4000, 150);

			
		system.autogenerateHyperspaceJumpPoints(false, false);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
