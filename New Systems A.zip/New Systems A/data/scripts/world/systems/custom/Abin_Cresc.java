package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.ids.Conditions;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Abin_Cresc {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Abin Cresc");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background_galatia.jpg");

		PlanetAPI star = system.initStar("abin_cresc", // unique id for this star
				"star_red_dwarf", // id in planets.json
				770f,		// radius (in pixels at default zoom)
				300, // corona radius, from star edge
				5f, // solar wind burn level
				1f, // flare probability
				2f); // cr loss mult
		system.setLightColor(new Color(250, 132, 0)); // light color in entire system, affects all entities

		PlanetAPI gangregis_khan = system.addPlanet("gangregis_khan", star, "Gangregis Khan", "fire_giant", 50, 310, 1800, 100);
		gangregis_khan.getSpec().setPlanetColor(new Color(117,0,98,255));
		gangregis_khan.getSpec().setAtmosphereColor(new Color(202,67,180,255));
		gangregis_khan.getSpec().setCloudColor(new Color(0,0,0,200));
		gangregis_khan.getSpec().setIconColor(new Color(202,67,180,255));
		gangregis_khan.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		gangregis_khan.getSpec().setGlowColor(new Color(202,67,180,145));
		gangregis_khan.getSpec().setUseReverseLightForGlow(true);
		gangregis_khan.getSpec().setAtmosphereThickness(0.5f);
		gangregis_khan.applySpecChanges();
		gangregis_khan.setCustomDescriptionId("planet_gangregis_khan");
		system.addCorona(gangregis_khan, Terrain.CORONA_AKA_MAINYU,
				300f, // radius outside planet
				5f, // burn level of "wind"
				0f, // flare probability
				1f // CR loss mult while in it
		);
		Misc.initConditionMarket(gangregis_khan);
		gangregis_khan.getMarket().addCondition(Conditions.RARE_ORE_RICH);
		gangregis_khan.getMarket().addCondition(Conditions.ORE_RICH);
		gangregis_khan.getMarket().addCondition(Conditions.VOLATILES_DIFFUSE);
		gangregis_khan.getMarket().addCondition(Conditions.DENSE_ATMOSPHERE);
		gangregis_khan.getMarket().addCondition(Conditions.VERY_HOT);
		gangregis_khan.getMarket().addCondition(Conditions.HIGH_GRAVITY);

		SectorEntityToken don_eladio2 = system.addCustomEntity("don_eladio2", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"nav_buoy_makeshift", // type of object, defined in custom_entities.json
				"independent"); // faction
		don_eladio2.setCircularOrbitPointingDown(star, -40, 1400, 100);

		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 2850, 160f);
		system.addRingBand(star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 3000, 160f);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 3120, 130f);
		system.addAsteroidBelt(star, 200, 3000, 200, 256, 280, Terrain.ASTEROID_BELT, "Am Alone");

		PlanetAPI denyza = system.addPlanet("denyza", star, "Denyza", "arid", 50, 180, 5400, 210);
		denyza.setCustomDescriptionId("planet_denyza");
		denyza.getSpec().setPitch(2f);
		denyza.getSpec().setTilt(8.8f);
		denyza.applySpecChanges();

		PlanetAPI maronia = system.addPlanet("maronia", star, "Maronia", "barren_venuslike", 50 - 60, 80, 5400, 210);
		maronia.setCustomDescriptionId("planet_maronia");
		maronia.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "asharu"));
		maronia.getSpec().setGlowColor(new Color(255,241,227,255));
		maronia.getSpec().setUseReverseLightForGlow(true);
		maronia.applySpecChanges();

		SectorEntityToken Denyza_L = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						600f, // max radius
						20, // min asteroid count
						30, // max asteroid count
						4f, // min asteroid radius
						16f, // max asteroid radius
						"Left Living Point")); // null for default name

		Denyza_L.setCircularOrbit(star, 50 - 60, 5400, 210);

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint", "Ogon Jump-point");
		jumpPoint.setCircularOrbit(star, 50 + 60, 5400, 410);
		jumpPoint.setRelatedPlanet(maronia);
		jumpPoint.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumpPoint);

		SectorEntityToken don_eladio = system.addCustomEntity("don_eladio", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"comm_relay_makeshift", // type of object, defined in custom_entities.json
				"independent"); // faction
		don_eladio.setCircularOrbitPointingDown(star, -120, 7500, 310);

		JumpPointAPI jumpPoint_extra = Global.getFactory().createJumpPoint("jumpPoint", "Ogon Jump-point");
		jumpPoint_extra.setCircularOrbit(star, -80, 7000, 410);
		jumpPoint_extra.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumpPoint_extra);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
				4, 6, // min/max entities to add
				10000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds
		
		
		// generates hyperspace destinations for in-system jump points
		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
}
