package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
//import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class No_Bono {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("No Bono");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background1.jpg");
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("no_bono", // unique id for star
				StarTypes.WHITE_DWARF, // id in planets.json
				520f,		// radius (in pixels at default zoom)
				400, // extent of corona outside star
				1f, // solar wind burn level
				0f, // flare probability
				1f); // CR loss multiplier, good values are in the range of 1-5
		
		//system.setLightColor(new Color(181, 29, 156)); // light color in entire system, affects all entities

		PlanetAPI alone = system.addPlanet("alone", star, "Alone", "barren", -75, 95, 1800, 100);

		PlanetAPI planet_null = system.addPlanet("planet_null", star, "Null", "lava_minor", 210, 160, 3800, 240);
		//planet_null.setCustomDescriptionId("planet_null");

		SectorEntityToken null_lag = system.addTerrain(Terrain.ASTEROID_FIELD,
				new AsteroidFieldParams(
						400f, // min radius
						600f, // max radius
						10, // min asteroid count
						15, // max asteroid count
						8f, // min asteroid radius
						12f, // max asteroid radius
						null)); // null for default name

		null_lag.setCircularOrbit(star, 210 - 80, 3800, 240);
		
			JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("jumpPoint_null", "Devoid");
			jumpPoint.setCircularOrbit(star, 210 - 80, 3800, 240);
			jumpPoint.setStandardWormholeToHyperspaceVisual();
			jumpPoint.setRelatedPlanet(planet_null);
			system.addEntity(jumpPoint);

		//SectorEntityToken empty_1 = system.addCustomEntity("empty_1", // unique id
		//		"Point Hyperstop", // name - if null, defaultName from custom_entities.json will be used
		//		"nav_buoy", // type of object, defined in custom_entities.json
		//		"sindrian_diktat"); // faction
		//empty_1.setCircularOrbitPointingDown(star, 150, 5000, 240);

		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 4500, 100, Terrain.RING, null);
		SectorEntityToken empty_2 = system.addCustomEntity("empty_2", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"comm_relay_makeshift", // type of object, defined in custom_entities.json
				"sindrian_diktat"); // faction
		empty_2.setCircularOrbitPointingDown(star, 160-60, 4500, 240);

		system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 4650, 190, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_special0", 256f, 2, Color.white, 256f, 4700, 240, Terrain.RING, null);

		float radiusAfter = StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
				2, 3, // min/max entities to add
				6000, // radius to start adding at
				0, // name offset - next planet will be <system name> <roman numeral of this parameter + 1>
				true, // whether to use custom or system-name based names
				false); // whether to allow habitable worlds

		PlanetAPI forbidden = system.addPlanet("forbidden", star, "Forbidden", "ice_giant", 120, 290, 11200, 400);
			PlanetAPI fameless = system.addPlanet("fameless", forbidden, "Fameless", "toxic_cold", 120, 60, 720, 32);
			fameless.setCustomDescriptionId("planet_fameless");

			//SectorEntityToken empty_3 = system.addCustomEntity("empty_3", // unique id
			//		null, // name - if null, defaultName from custom_entities.json will be used
			//		"sensor_array_makeshift", // type of object, defined in custom_entities.json
			//		"sindrian_diktat"); // faction
			//empty_3.setCircularOrbitPointingDown(forbidden, -60, 2500, 40);

		StarSystemGenerator.addSystemwideNebula(system, StarAge.YOUNG);

		system.autogenerateHyperspaceJumpPoints(true, true);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
		
	
}
