package data.scripts.world.systems.custom;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;

import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;

import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;

public class Cappuccino {

	public void generate(SectorAPI sector) {
		StarSystemAPI system = sector.createStarSystem("Cappuccino");
		LocationAPI hyper = Global.getSector().getHyperspace();
		system.setBackgroundTextureFilename("graphics/backgrounds/background4.jpg");

		//SectorEntityToken hybrasil_nebula = Misc.addNebulaFromPNG("data/campaign/terrain/hybrasil_nebula.png",
				//0, 0, // center of nebula
				//system, // location to add to
				//"terrain", "nebula", // "nebula_blue", // texture to use, uses xxx_map for map
				//4, 4, StarAge.AVERAGE); // number of cells in texture
		
		// create the star and generate the hyperspace anchor for this system
		PlanetAPI star = system.initStar("cappuccino", // unique id for star
				StarTypes.BROWN_DWARF, // id in planets.json
				425f,		// radius (in pixels at default zoom)
				300, // extent of corona outside star
				1f, // solar wind burn level
				0f, // flare probability
				1f); // CR loss multiplier, good values are in the range of 1-5
		
		system.setLightColor(new Color(162, 29, 155)); // light color in entire system, affects all entities

		//system is too crowded, removing these. Brown giant shouldn't have that much shit going on
		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, new Color(200,220,200,255), 256f, 2700, 120f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, new Color(200,220,200,255), 256f, 2800, 150f, Terrain.RING, null);
		system.addRingBand(star, "misc", "rings_dust0", 256f, 1, new Color(200,220,200,255), 256f, 2000, 150f, Terrain.RING, null);
		//https://youtu.be/Jn06G6hu9uU

		PlanetAPI gumbat = system.addPlanet("gumbat", star, "Gumbat", "toxic", -120, 130, 1500, 70);
		gumbat.setCustomDescriptionId("planet_gumbat");
		gumbat.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
		gumbat.getSpec().setGlowColor(new Color(181,29,35,155));
		gumbat.getSpec().setPitch(20f);
		gumbat.getSpec().setUseReverseLightForGlow(true);
		gumbat.applySpecChanges();

		JumpPointAPI jumpPoint = Global.getFactory().createJumpPoint("gumbat_jump", "Espresso Jump-point");
		jumpPoint.setCircularOrbit( system.getEntityById("cappuccino"), 0, 2700, 140);
		system.addEntity(jumpPoint);
		jumpPoint.setRelatedPlanet(gumbat);
		jumpPoint.setStandardWormholeToHyperspaceVisual();
		jumpPoint.setRelatedPlanet(gumbat);

		SectorEntityToken gumbat_relay = system.addCustomEntity("gumbat_relay", // unique id
				"Free TV Corporate Satellite", // name - if null, defaultName from custom_entities.json will be used
				"comm_relay", // type of object, defined in custom_entities.json
				"tritachyon"); // faction
		gumbat_relay.setCircularOrbitPointingDown(star, -120, 3000, 180);

		JumpPointAPI jumpPoint_extra = Global.getFactory().createJumpPoint("jumpPoint_extra", "Intermediary Jump-point");
		jumpPoint_extra.setCircularOrbit(system.getEntityById("cappuccino"), 100, 5700, 400);
		system.addEntity(jumpPoint_extra);
		jumpPoint_extra.setStandardWormholeToHyperspaceVisual();

		PlanetAPI grabuz = system.addPlanet("grabuz", star, "Grabuz", "ice_giant", -45, 320, 8000, 600);
		PlanetAPI sos = system.addPlanet("sos", grabuz, "Song of Soul", "cryovolcanic", 40, 40, 500, 18);
		system.addRingBand(grabuz, "misc", "rings_special0", 256f, 1, new Color(200,200,200,255), 256f, 800, 100f, Terrain.RING, null);
		system.addRingBand(grabuz, "misc", "rings_special0", 256f, 1, new Color(200,200,200,255), 256f, 900, 100f, Terrain.RING, null);

		PlanetAPI som = system.addPlanet("som", grabuz, "Song of Mind", "barren2", 40, 80, 1200, 55);

		SectorEntityToken grabuz_array = system.addCustomEntity("grabuz_array", // unique id
				null, // name - if null, defaultName from custom_entities.json will be used
				"sensor_array_makeshift", // type of object, defined in custom_entities.json
				"tritachyon"); // faction
		grabuz_array.setCircularOrbitPointingDown(grabuz, -225, 5000, 600);

		system.autogenerateHyperspaceJumpPoints(true, false);

		//StarSystemGenerator.addSystemwideNebula(system, StarAge.OLD);
		cleanup(system);

	}

	void cleanup(StarSystemAPI system) {
		HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);
		float minRadius = plugin.getTileSize() * 2f;

		float radius = system.getMaxRadiusInHyperspace();
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
		editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
	}
		
	
}
